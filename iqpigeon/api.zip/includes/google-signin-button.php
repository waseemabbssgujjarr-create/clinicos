<?php
/**
 * Google sign-in button partial.
 * @var string $googleMode login|register
 */
require_once __DIR__ . '/google-oauth.php';
require_once __DIR__ . '/integration-settings.php';

$googleMode = $googleMode ?? 'login';

if (!integration_google_signin_enabled()) {
    return;
}

$googleReady = google_signin_available();
$href = $googleReady
    ? '/api/auth/google-start.php?mode=' . rawurlencode($googleMode)
    : '/login.php?google_error=not_configured';
if (!$googleReady && $googleMode === 'register') {
    $href='/register?google_error=not_configured';
}
?>
<a href="<?= sanitize($href) ?>"
   class="auth-oauth-btn<?= $googleReady ? '' : ' opacity-80' ?>"
   <?= $googleReady ? '' : ' title="Google sign-in will be available soon"' ?>>
    <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true">
        <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303C33.654 32.657 29.083 36 24 36c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C33.64 6.053 29.082 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
        <path fill="#FF3D00" d="m6.306 14.691 6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C33.64 6.053 29.082 4 24 4 16.318 4 9.656 8.337 6.306 14.691z"/>
        <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238C29.211 35.091 26.715 36 24 36c-5.059 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/>
        <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/>
    </svg>
    Continue with Google
</a>
